from flask import Flask, request, render_template,send_file,Response

from PIL import Image, ImageEnhance
import numpy as np

import os
import cv2
import glob
import uuid
import io

from elasticsearch import Elasticsearch
import json


app = Flask(__name__)
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0

UPLOAD_FOLDER = os.path.basename('uploads')
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

image_stage_names = ["step1.png", "step2.png"]
directory_list = ["dumps", "text", "original", "uploads"]
text_file_list = ["data1.txt", "data2.txt", "data3.txt"]



def check_dpi(UPLOAD_FOLDER, image_name):
    try:
        image_test = Image.open(os.path.join(UPLOAD_FOLDER, image_name))
        return image_test.info['dpi'][0]
    except:
        print('ERROR___DPI INFO NOT FOUND')
        return 0


def enhance_Images(image_obj):
    # _,threshold = cv2.threshold(image_temp,230,255,cv2.THRESH_BINARY)
    # threshold = cv2.threshold(image_temp, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
    blur = cv2.bilateralFilter(image_obj, 9, 75, 75)
    kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])
    sharpen = cv2.filter2D(blur, -1, kernel)

    return sharpen


def dirHasher(file_name):
    uniqueID = uuid.uuid4()
    get_extension = os.path.splitext(file_name)[1]
    newFileName = str(uniqueID) + str(get_extension)
    os.rename(file_name, os.path.join(UPLOAD_FOLDER, newFileName))
    return newFileName


def clean_Directory(dirName):
    files = glob.glob(str(dirName) + '/*')
    try:
        for f in files:
            os.remove(f)
        print("[INFO] " + str(dirName) + " Directory cleared")
    except:
        print("[ERROR] 2")


@app.route("/")
def hello():
    clean_Directory(directory_list[0])
    clean_Directory(directory_list[3])
    return '''<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Flask</title>
  <link rel="stylesheet" href="https://unpkg.com/picnic">
</head>

<body>
    <a style="margin:10px; background: #228b22;" class="button" href="/search">Search</a>

  <article style="margin:10px; width:40%" class="card">
    <header>
      <h3>Upload Image</h3>
    </header>
    <footer>
      <form action="/upload" method="post" enctype="multipart/form-data">
        <input type="file" name="image" required>




        <input type="submit" value="UPLOAD" class="btn btn-primary">
      </form>
    </footer>
  </article>


</body>

</html>'''


@app.route("/upload", methods=['POST'])
def upload_file():
    file = request.files['image']
    if (file):
        # print(vars(file))
        f = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)

        extension = file.filename.rsplit('.')
        extension = extension[len(extension) - 1]

        if (extension == 'jpg' or extension == 'jpeg' or extension == 'png'):
            file.save(f)
            print('[INFO] file uploaded ' + file.filename)
            image_name = dirHasher(f)
            id = image_name.rsplit('.')[0]
            # image_name = os.path.join(UPLOAD_FOLDER,image_name)
            return image_name

        else:
            return "FILETYPE not supported"
        data = {"message": "OCR Done", "id": id}
        print('redirection from here......................')
        return '**********************UPLOAD DONE*******************************'
    else:
        return "ERROR"

@app.route("/enchance", methods=['GET'])

def enchance():
    image_name= request.args.get('image_name')
    image_obj = cv2.imread(os.path.join(UPLOAD_FOLDER, image_name))
    dpi = check_dpi(UPLOAD_FOLDER, image_name)
    print('DPI VALUE.....:', dpi)
    if dpi == 0 or dpi < 300:
        result = enhance_Images(image_obj)
        cv2.imwrite(os.path.join(UPLOAD_FOLDER, image_name), result)
        print('reached.......................')
        return send_file(os.path.join(UPLOAD_FOLDER, image_name), mimetype='image')
        return 'IMAGE ENCHANCED FOR BETTER RESULTS__________________THE DPI VALUE IS:' + str(dpi)


    else:
        print('reached..................')
        return send_file(os.path.join(UPLOAD_FOLDER, image_name), mimetype='image')
        return 'IMAGE ENCHANCED SKIPPED__________________THE DPI VALUE IS:' + str(dpi)


def performOCR(temp_image_name, fileName):
    command = "tesseract %s stdout -l eng --oem 1 --psm 3 >> %s" % (
        temp_image_name, fileName)
    data = os.system(command)
    # print(data)
    return data


def resizeSample(image_name, image_obj, resolution_threshold, new_image_name):
    if (image_obj.shape[1] < resolution_threshold):
        ratio = float(image_obj.shape[0]) / image_obj.shape[1]
        size = int(resolution_threshold), int(resolution_threshold * ratio)
    else:
        size = image_obj.shape[1], image_obj.shape[0]
    try:
        im = Image.open(image_name)
        im_resized = im.resize(size, Image.ANTIALIAS)
        enhancer = ImageEnhance.Sharpness(im_resized)
        im_resized = enhancer.enhance(2)

        im_resized.save(new_image_name, dpi=(300, 300))

        imageA = cv2.imread(new_image_name)
        kernel_sharpen = np.array([[-1, -1, -1, -1, -1],
                                   [-1, 2, 2, 2, -1],
                                   [-1, 2, 8, 2, -1],
                                   [-1, 2, 2, 2, -1],
                                   [-1, -1, -1, -1, -1]]) / 8.0

        output_3 = cv2.filter2D(imageA, -1, kernel_sharpen)
        blur = cv2.GaussianBlur(output_3, (1, 1), 0)
        cv2.imwrite(new_image_name, blur)

        print("[INFO] Image resized from " +
              str((image_obj.shape[1], image_obj.shape[0])) + " to " + str(size))

    except:

        print("[ERROR] 1")

    return 0


def textSegmentation(image_name):
    nameList = []

    image = cv2.imread(image_name, 0)
    _, thresh1 = cv2.threshold(image, 127, 255, cv2.THRESH_BINARY_INV)
    kernal = np.ones((5, 5), np.uint8)
    print('try1............................')
    dilation = cv2.dilate(thresh1, kernal, iterations=5)
    filtered = cv2.blur(dilation, (5, 5))
    print('try............................')
    __, contours, __ = cv2.findContours(
        filtered, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)
    print("contours : ", len(contours))
    counter = 0
    for cont in contours:
        cont_area = cv2.contourArea(cont)
        if cont_area > 1000:
            x, y, w, h = cv2.boundingRect(cont)
            cv2.rectangle(image, (x, y), (x + w, y + h), (0, 255, 0), 2)
            cropped = image[y:y + h, x:x + w]
            filepath = "dumps/" + str(counter) + ".jpg"
            cv2.imwrite(filepath, cropped)
            nameList.append(filepath)
            counter += 1

    # cv2.imshow("test1", imutils.resize(filtered, height=500))
    # cv2.imshow("test", imutils.resize(image, height=500))
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()
    return nameList


def enhance_Segmented_Images(segmentList):
    for segment in segmentList:
        image_temp = cv2.imread(segment, 0)
        # _,threshold = cv2.threshold(image_temp,230,255,cv2.THRESH_BINARY)
        # threshold = cv2.threshold(image_temp, 0, 255, cv2.THRESH_BINARY | cv2.THRESH_OTSU)[1]
        blur = cv2.bilateralFilter(image_temp, 9, 75, 75)
        kernel = np.array([[-1, -1, -1], [-1, 9, -1], [-1, -1, -1]])
        sharpen = cv2.filter2D(blur, -1, kernel)

        cv2.imwrite(segment, sharpen)
    return "Done"


@app.route("/extract", methods=['GET'])
def extract():
    clean_Directory(directory_list[1])

    try:
        for image_name in glob.glob("uploads/*"):
            image_name = image_name.strip('uploads/')
            print(image_name)
            image_obj = cv2.imread(os.path.join(UPLOAD_FOLDER, image_name))
            for x in range(0, len(text_file_list)):
                temp_name = text_file_list[x]
                get_filename = os.path.splitext(image_name)[0]
                new_name = str(get_filename) + "_" + str(temp_name)
                text_file_list[x] = new_name

                # print(text_file_list)

            image_name = os.path.join(directory_list[3], image_name)
            data1 = performOCR(image_name, os.path.join(
                directory_list[1], text_file_list[0]))

            print('REACHED FIRST PART........................................................')

            resizeSample(image_name, image_obj,
                         1800, image_stage_names[0])
            data2 = performOCR(image_stage_names[0], os.path.join(
                directory_list[1], text_file_list[1]))

            print('REACHED SECOND PART........................................................')

            segmentList = textSegmentation(image_stage_names[0])
            print(len(segmentList))
            enhance_Segmented_Images(segmentList)

            for segment in segmentList:
                temp = performOCR(segment, os.path.join(
                    directory_list[1], text_file_list[2]))

            path = 'texts'
            data = ''
            for filename in glob.glob(os.path.join(path, '*.txt')):
                data += filename
                print('.......................' + data)

            out = ''
            for filename in glob.glob('text/*.txt'):
                print(filename)
                text = open(filename, 'r')
                for i in text:
                    out += i
            f = io.StringIO(out)
            print(f)

            return Response(f, mimetype='text')



    except:
        print('ERROR----TEXT EXTRACTION NOT DONE')
        return 'ERROR OCCURED WHILE EXTRACTING'

def elastic_search_connect():
    _es = Elasticsearch([{'host': 'localhost', 'port': 9200}])
    if _es.ping():
        print('Yay Connect')
    else:
        print('Awww it could not connect!')
    return _es

def search(es_object, index_name, search):
        res = es_object.search(index=index_name, body=search)
        return res


@app.route("/search_word_alike", methods=['GET'])
def elastic_search_wordalike_search():
    _es=elastic_search_connect()
    if _es is not None:
        search_object = {
  "_source": ["path.real","content"],
  "query": {
    "match_phrase_prefix": {
      "content": {
            "query": "NUMERO"
            , "max_expansions": 10
    }
  }
      },

   "highlight": {
    "fields": {
      "content": {}
    }
  }
}
        result_list = ''
        res = search(_es, 'job_name', json.dumps(search_object))
        print(res)
        result = res['hits']['hits']
        result = result[0]['highlight']['content']
        for x in result:
            result_list+= x.split('<em>')[1].split('</em>')[0]
            print(result_list)
        return result_list

@app.route("/search_num", methods=['GET'])
def elastic_search_num_search():
    _es=elastic_search_connect()
    if _es is not None:
        search_object = {
            "_source": ["path.real", "content"],
            "query": {
                "regexp": {
                    "content": "(.*)([0-9]{10})"
                }
            }
            , "highlight": {
                "fields": {
                    "content": {}
                }
            }
        }
        result_list = ''
        res = search(_es, 'job_name', json.dumps(search_object))
        print(res)
        result = res['hits']['hits']
        result = result[0]['highlight']['content']
        for x in result:
            result_list+= x.split('<em>')[1].split('</em>')[0]
            print(result_list)
        return result_list

@app.route("/search_exact_match", methods=['GET'])
def elastic_search_exact_match():
    _es=elastic_search_connect()
    if _es is not None:
        search_object = {
  "_source": ["path.real","content"],
  "query": {
    "multi_match": {
      "query": "NUMERO RUC",
      "fields": ["content"],
      "type": "best_fields"
    }
    
  }, 
  
   "highlight": {
    "fields": {
      "content": {}
    }
  }
}

        result_list = ''
        res = search(_es, 'job_name', json.dumps(search_object))
        print(res)
        result = res['hits']['hits']
        result = result[0]['highlight']['content']
        for x in result:
            result_list+= x.split('<em>')[1].split('</em>')[0]
            print(result_list)
        return result_list


if __name__ == "__main__":
    # app.run(debug=True)
    app.run(host='0.0.0.0', port=5001)

